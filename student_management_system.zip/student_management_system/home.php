<?php
include("head.php");
 ?>


<div class="container">
  <h1>Student Management System </h1>
  <img src="logo.png">
  <br/>
  <a href="student.php" class="btn btn-info" role="button">Students</a>
  
   <a href="teacher.php" class="btn btn-info" role="button">teachers</a>
</div>

</body>
</html>