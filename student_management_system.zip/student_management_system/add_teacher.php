<?php
include("head.php");
include("db.php");
if(isset($_POST["reg"]) && $_POST["reg"]=="Submit")
{
$id=	$_POST["tid"];
$fname= $_POST["fname"];
$lname= $_POST["lname"];
$address= $_POST["address"];

/////////getting birthday ////
//උපන්දිනේ වෙන වෙනම /////
$year= $_POST["byear"];
$month= $_POST["bmonth"];
$day= $_POST["bday"];

///////////////////////////////////


$full_bday="$year/$month/$day";



/////////getting join day ////
//වෙන වෙනම /////
$jyear= $_POST["jyear"];
$jmonth= $_POST["jmonth"];
$jday= $_POST["jday"];

///////////////////////////////////


$full_jday="$jyear/$jmonth/$jday";





$gender=$_POST["sex"];

$sub=$_POST["sub"];
	
$insert_sql= "INSERT INTO `teacher`(`id`, `fname`, `lname`, `address`, `bday`, `gender`, `join_date`, `subject`) VALUES ('$id','$fname','$lname','$address','$full_bday','$gender','$full_jday','$sub')";	



if (mysqli_query($conn, $insert_sql)) {

  echo'<div class="alert alert-success">
  <strong>Success!</strong> New record created successfully
</div>';
  
  
  
} else {
  
 echo' <div class="alert alert-warning">
  <strong>Warning!</strong> error in registering the teacher
</div>';

  
  
  
}


	
}

?>















<div class="container">
  <h2>Add teacher </h2>
  <form action="?" method="POST">
  
  
  	    <div class="form-group">
      <label for="sid">teacher ID:</label>
	  <?php
	  //දැනට අවසානයට තියෙන teacher id එක ලබා ගැනීම ////
	  /////////////////////////
	  $sql = "SELECT MAX(id) FROM teacher";
      $result = mysqli_query($conn, $sql);
	  $last_id= mysqli_fetch_array($result);
	  ////////////////////////
	  
	  ////////// අවසානයට 1 එකක් එකතු කිරීම /////
	  $new_id = $last_id[0]+1;
	  ?>
      <input type="text" class="form-control" value="<?php echo $new_id; ?>" placeholder="Enter ID" name="tid">
    </div>
	
  
  
  
    <div class="form-group">
      <label for="fname">First name:</label>
      <input type="text" class="form-control"  placeholder="Enter first name" name="fname" required>
    </div>

        <div class="form-group">
      <label for="lname">Last name:</label>
      <input type="text" class="form-control"  placeholder="Enter Last Name" name="lname" required>
    </div>
	
	
        <div class="form-group">
      <label for="uname">Address:</label>

  <textarea name="address" class="form-control" rows="5" ></textarea>

    </div>
	
	
	        <div class="form-group">
      <label for="uname">Birthday:</label>
	  
	 <div class="row">
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter YEAR" name="byear" required></div>
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter MONTH" name="bmonth" required></div>
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter day" name="bday" required></div>
</div> 

	
	</div>
	
	   <div class="form-group">
	   
	 <label for="uname">Gender:</label>   
	   
<label class="radio-inline"><input type="radio" name="sex" value="m" checked>Male</label>
<label class="radio-inline"><input type="radio" name="sex" value="f">Female</label>
		</div>
	
	
	
  <div class="form-group">
      <label for="uname">School Join Date:</label>
	  
	 <div class="row">
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter YEAR" name="jyear" required></div>
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter MONTH" name="jmonth" required></div>
  <div class="col-sm-4"><input type="text" class="form-control"  placeholder="Enter day" name="jday" required></div>
</div> 

	
	</div>
		
	
	
	       <div class="form-group">
      <label for="lname">what Subject are teaching:</label>
      <input type="text" class="form-control"  placeholder="Enter subject" name="sub" required>
    </div>
	
	
	
	
	
	
	
	
    <input type="submit" name="reg" class="btn btn-primary btn-block" value="Submit">
  </form>
</div>

</body>
</html>