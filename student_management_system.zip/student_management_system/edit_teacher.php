<?php
include("head.php");
include("db.php");

//take the  id
	$id=$_GET['id'];
if(isset($_POST["edit"]) && $_POST["edit"]=="edit")
{
$tid=	$_POST["tid"];
$fname= $_POST["fname"];
$lname= $_POST["lname"];
$address= $_POST["address"];

/////////getting birthday ////
//උපන්දිනේ වෙන වෙනම /////
$year= $_POST["byear"];
$month= $_POST["bmonth"];
$day= $_POST["bday"];

///////////////////////////////////


$full_bday="$year/$month/$day";



/////////getting join day ////
//වෙන වෙනම /////
$jyear= $_POST["jyear"];
$jmonth= $_POST["jmonth"];
$jday= $_POST["jday"];

///////////////////////////////////


$full_jday="$jyear/$jmonth/$jday";





$gender=$_POST["sex"];

$sub=$_POST["sub"];
	
	
$update_sql= "UPDATE `teacher` SET `id`='$tid', `fname`='$fname', `lname`='$lname', `address`='$address', `bday`='$full_bday', `gender`='$gender', `join_date`='$full_jday', `subject`='$sub' WHERE id=$id";	


if (mysqli_query($conn, $update_sql)) {

  echo'<div class="alert alert-success">
  <strong>Success!</strong> New record created successfully
</div>';
  
  
  
} else {
  
 echo' <div class="alert alert-warning">
  <strong>Warning!</strong> error in updating the teacher
</div>';

  
  
  
}


	
}

?>







<?php

//define the select query
$query="select * from teacher where id=$id";

//execute the query
$result=mysqli_query($conn, $query) or die("error in retrieving the record");

//assign the row values to the table columns
$row=mysqli_fetch_array($result);





?>







<div class="container">
  <h2>Edit teacher </h2>
  <form action="?id=<?php echo $id;?>" method="POST">
  
  
  	
	   <form action="?id=<?php echo $id;?>" method="POST">
  
  
  	    <div class="form-group">
      <label for="sid">teacher ID:</label>
      <input type="text" class="form-control"  value="<?php echo $row['id']; ?>" name="tid">
    </div>
	
  
  
  
    <div class="form-group">
      <label for="fname">First name:</label>
      <input type="text" class="form-control" value="<?php echo $row['fname']; ?>" name="fname">
    </div>

        <div class="form-group">
      <label for="lname">Last name:</label>
      <input type="text" class="form-control" value="<?php echo $row['lname']; ?>"  name="lname">
    </div>
	
	
        <div class="form-group">
      <label for="uname">Address:</label>

  <textarea name="address" class="form-control" rows="5" ><?php echo $row['address']; ?></textarea>

    </div>

	
	
	<?php
	
$bday=$row["bday"];	
$year= date("Y", strtotime($bday));
$month= date("m", strtotime($bday));
$day= date("d", strtotime($bday));
?>
	

	
	        <div class="form-group">
      <label for="uname">Birthday:</label>
	  
	 <div class="row">
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $year; ?>" placeholder="Enter YEAR" name="byear"></div>
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $month; ?>" placeholder="Enter MONTH" name="bmonth"></div>
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $day; ?>" placeholder="Enter day" name="bday"></div>
</div> 

	
	</div>
	
	   <div class="form-group">
	   
	 <label for="uname">Gender:</label>   
	

	<?php
	
$sex=$row["gender"];	

?>


<?php
if($sex=="m"){
?>
<label class="radio-inline"><input type="radio" name="sex" value="m" checked>Male</label>
<label class="radio-inline"><input type="radio" name="sex" value="f">Female</label>
<?php }else{?>	
	
	<label class="radio-inline"><input type="radio" name="sex" value="m">Male</label>
<label class="radio-inline"><input type="radio" name="sex" value="f" checked>Female</label>
	
<?php } ?>
	
	
	
	</div>
	
	
	
  <div class="form-group">
      <label for="uname">School Join Date:</label>
	  
<?php
	
$jdayx=$row["join_date"];	
$jyear= date("Y", strtotime($jdayx));
$jmonth= date("m", strtotime($jdayx));
$jday= date("d", strtotime($jdayx));
?>
	

	
	  
	 <div class="row">
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $jyear; ?>" placeholder="Enter YEAR" name="jyear"></div>
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $jmonth; ?>" placeholder="Enter MONTH" name="jmonth"></div>
  <div class="col-sm-4"><input type="text" class="form-control" value="<?php echo $jday; ?>" placeholder="Enter day" name="jday"></div>
</div> 
	
	</div>
		
	
	
	       <div class="form-group">
      <label for="lname">what Subject are teaching:</label>
      <input type="text" class="form-control"  value="<?php echo $row["subject"]; ?>" placeholder="Enter subject" name="sub" required>
    </div>
	
	
	
	
	
	
	
	
    <input type="submit" name="edit" class="btn btn-primary btn-block" value="edit">
  </form>
</div>

</body>
</html>