<?php
include 'head.php';
//connect to the database 
include 'db.php';



if(isset($_GET['id']))
{
	//take the  id
	$id=$_GET['id'];

	//define the delete query
	$query="delete from teacher where id ='$id'";
	//execute the delete query
	$res=mysqli_query($conn, $query);
	if($res)
	{
  echo'<div class="alert alert-success">
  <strong>Success!</strong> record Deleted successfully
</div>';

	}else{
		
	 echo' <div class="alert alert-warning">
  <strong>Warning!</strong> error in deleting the students
</div>';	
		
	}
}
?>




<div class="container">
  <h2>teachers List </h2>

<table class="table">   <thead>
  <tr>
    <th>teacher_id</th>
    <th>Full Name</th>
    <th>Subject</th>
	    <th></th>
  </tr>
     </thead><tbody>
<?php
//define the select query
$query="select * from teacher";

//execute the query
$result=mysqli_query($conn, $query) or die("error in retrieving the record");

//assign the row values to the table columns
while($row=mysqli_fetch_array($result))
{
	echo  "<tr><td>".$row['id']."</td>";
	
	echo  "<td>".$row['fname'];
	echo  " ".$row['lname']."</td>";
	echo  "<td>".$row['subject']."</td>";


//edit link
	echo  "<td><a href=edit_teacher.php?id=".$row['id'].">EDIT</a> / ";
	
//delete link
	echo  "<a href=?id=".$row['id']."
    onclick=\"return confirm('Are you sure?');\"   type=\"button\" class=\"btn btn-danger\"  >Delete</a></td></tr>";
	



}
  
  ?>
  
  
  
  
 </tbody> 
  
</table>  
  
  




   
</div>

</body>
</html>