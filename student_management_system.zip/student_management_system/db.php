<?php

$hostname="localhost";
$username="root";
$password="";
$dbname="student";
 
//get the connection to the database
$conn=mysqli_connect($hostname,$username,$password,$dbname) or die("error in connecting to server");


?>